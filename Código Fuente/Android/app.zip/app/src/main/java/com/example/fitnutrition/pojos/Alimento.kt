package com.example.fitnutrition.pojos

class Alimento {
    val idAlimento = 0
    val nombre: String = ""
    var calorias_por_porcion:String = ""
    val porcion: String = ""
}