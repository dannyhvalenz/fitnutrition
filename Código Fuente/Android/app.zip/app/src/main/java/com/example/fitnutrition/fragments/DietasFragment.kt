package com.example.fitnutrition.fragments

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnutrition.R
import com.example.fitnutrition.adaptador.AdaptadorListaCita
import com.example.fitnutrition.adaptador.AdaptadorListaDieta
import com.example.fitnutrition.pojos.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.fragment_citas.*
import kotlinx.android.synthetic.main.fragment_dietas.*

class DietasFragment : Fragment() {
    private var idPaciente:String? = null
    private var activity : Activity? = null
    private var consulta = Consulta()
    private var dieta = Dieta()
    private var comidasDieta = ArrayList<Dieta>()
    private var dietas = ArrayList<Dieta>()
    private var nombreComidas = Alimento()
    private var nombreDieta = ArrayList<Dieta>()
    private var nombres = ArrayList<String>()
    private lateinit var txtOcultaDetalleDietaActual : TextView
    private lateinit var txtDetalleDietaActual : TextView
    private lateinit var lyComidasDietaActual : LinearLayout
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var v: View = inflater.inflate(R.layout.fragment_dietas, container, false)
        activity = this.getActivity()
        val bundle:Bundle? = this.getArguments()
        idPaciente = bundle?.getString("paciente")
        System.out.println(idPaciente)
        txtDetalleDietaActual = v.findViewById(R.id.txtDetalleDietaActual)
        txtOcultaDetalleDietaActual = v.findViewById(R.id.txtOcultaDetalleDietaActual)
        lyComidasDietaActual = v.findViewById(R.id.lyComidasDietaActual)
        txtDetalleDietaActual.setOnClickListener(View.OnClickListener {
            lyComidasDietaActual.visibility=View.VISIBLE
            txtDetalleDietaActual.visibility=View.GONE
        })
        txtOcultaDetalleDietaActual.setOnClickListener(View.OnClickListener {
            lyComidasDietaActual.visibility=View.GONE
            txtDetalleDietaActual.visibility=View.VISIBLE
        })
        getUltimaConsulta()
        return v
    }
    fun getUltimaConsulta(){
        Ion.getDefault(activity).conscryptMiddleware.enable(false)
        Ion.with(activity)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/consultas/getConsultaByIDPaciente")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idPaciente", idPaciente)
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        //Log.d("idPaciente", idPaciente)
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        consulta= gson.fromJson(result, Consulta::class.java)
                        if(consulta==null){
                            Toast.makeText(activity, "No existen consultas agendadas", Toast.LENGTH_LONG).show()
                        }else{
                            recuperarDieta()
                        }
                    }
                }
    }

    fun recuperarDieta(){
        Ion.getDefault(activity).conscryptMiddleware.enable(false)
        Ion.with(activity)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/dietas/getDietaByID")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idDieta", consulta.idDieta.toString())
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS 1", result)
                        val gson = Gson()
                        dieta= gson.fromJson(result, Dieta::class.java)
                        if(dieta==null){
                            Toast.makeText(activity, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                        }else{
                            recuperarComidasDieta()
                            getDietas()
                        }
                    }
                }
    }

    fun recuperarComidasDieta(){
        Ion.getDefault(activity).conscryptMiddleware.enable(false)
        Ion.with(activity)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/dietas/getDietaByNombre")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("nombre", dieta.nombre)
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS 2", result)
                        val gson = Gson()
                        val arrType = object: TypeToken<ArrayList<Dieta>>(){}.type
                        comidasDieta = gson.fromJson(result, arrType)
                        if(dieta==null){
                            Toast.makeText(activity, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                        }else{
                            llenarDieta()
                        }
                    }
                }
    }

    fun llenarDieta(){
        txtNombreDietaActual.text = dieta.nombre
        for(i in 0.. comidasDieta.size.minus(1)){
            if(comidasDieta[i].horaDia.equals("Desayuno")){
                Ion.getDefault(activity).conscryptMiddleware.enable(false)
                Ion.with(activity)
                        .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/alimentos/getAlimentoByID")
                        .setHeader("Content-Type", "application/x-www-form-urlencoded")
                        .setBodyParameter("idAlimento", comidasDieta[i].idAlimento.toString())
                        .asString()
                        .setCallback { e, result ->
                            if(e != null){
                                e.printStackTrace()
                                Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                            }else{
                                val gson = Gson()
                                nombreComidas= gson.fromJson(result, Alimento::class.java)
                                if(dieta==null){
                                    Toast.makeText(activity, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                                }else{
                                    txtNombreComidaDesayunoActual.text = nombreComidas.nombre
                                    txtCantidadDesayunoActual.text = nombreComidas.porcion
                                    txtCaloriasDesayunoActual.text = nombreComidas.calorias_por_porcion
                                    txtCaloriasDesayunoActual.text = comidasDieta[i].observaciones
                                }
                            }
                        }
            }
            if(comidasDieta[i].horaDia.equals("Comida")){
                Ion.getDefault(activity).conscryptMiddleware.enable(false)
                Ion.with(activity)
                        .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/alimentos/getAlimentoByID")
                        .setHeader("Content-Type", "application/x-www-form-urlencoded")
                        .setBodyParameter("idAlimento", comidasDieta[i].idAlimento.toString())
                        .asString()
                        .setCallback { e, result ->
                            if(e != null){
                                e.printStackTrace()
                                Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                            }else{
                                val gson = Gson()
                                nombreComidas= gson.fromJson(result, Alimento::class.java)
                                if(dieta==null){
                                    Toast.makeText(activity, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                                }else{
                                    txtNombreComidaComidaActual.text = nombreComidas.nombre
                                    txtCantidadComidaActual.text = nombreComidas.porcion
                                    txtCaloriasComidaActual.text = nombreComidas.calorias_por_porcion
                                    txtCaloriasComidaActual.text = comidasDieta[i].observaciones
                                }
                            }
                        }
            }
            if(comidasDieta[i].horaDia.equals("Cena")){
                Ion.getDefault(activity).conscryptMiddleware.enable(false)
                Ion.with(activity)
                        .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/alimentos/getAlimentoByID")
                        .setHeader("Content-Type", "application/x-www-form-urlencoded")
                        .setBodyParameter("idAlimento", comidasDieta[i].idAlimento.toString())
                        .asString()
                        .setCallback { e, result ->
                            if(e != null){
                                e.printStackTrace()
                                Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                            }else{
                                val gson = Gson()
                                nombreComidas= gson.fromJson(result, Alimento::class.java)
                                if(dieta==null){
                                    Toast.makeText(activity, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                                }else{
                                    txtNombreComidaCenaActual.text = nombreComidas.nombre
                                    txtCantidadCenaActual.text = nombreComidas.porcion
                                    txtCaloriasCenaActual.text = nombreComidas.calorias_por_porcion
                                    txtCaloriasCenaActual.text = comidasDieta[i].observaciones
                                }
                            }
                        }
            }
        }
    }

    fun getDietas(){
        Ion.with(activity)
                .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/dietas/getAllDietas")
                .asString()
                .setCallback{e, result ->
                    if(e!=null){
                        e.printStackTrace()
                        Toast.makeText(activity, e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        val arrType = object: TypeToken<ArrayList<Dieta>>(){}.type
                        dietas = gson.fromJson(result, arrType)
                        cargarNombresDietas();
                    }
                }
    }

    fun cargarNombresDietas(){
        Ion.with(activity)
                .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/dietas/getGrupoDietaByNombre")
                .asString()
                .setCallback{e, result ->
                    if(e!=null){
                        e.printStackTrace()
                        Toast.makeText(activity, e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        val arrType = object: TypeToken<ArrayList<Dieta>>(){}.type
                        nombreDieta = gson.fromJson(result, arrType)
                        if(nombreDieta==null){
                            Toast.makeText(activity, "No se encontraron los nombres de la dieta", Toast.LENGTH_LONG).show()
                        }else{
                            for(i in 0.. nombreDieta.size.minus(1)){
                                nombres.add(nombreDieta[i].nombre)
                            }
                            cargarDietas()
                        }
                    }
                }
    }

    fun cargarDietas(){
        val adaptadorListaDieta = AdaptadorListaDieta(nombres, dieta.nombre, activity)
        adaptadorListaDieta.dietas = dietas
        val layoutManager = LinearLayoutManager(activity)
        rvlistaOtrasDietas.layoutManager = layoutManager
        rvlistaOtrasDietas.adapter = adaptadorListaDieta
    }
}