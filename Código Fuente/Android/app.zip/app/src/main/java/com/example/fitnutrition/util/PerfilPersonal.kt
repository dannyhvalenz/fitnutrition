package com.example.fitnutrition.util

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Mensaje
import com.example.fitnutrition.pojos.Paciente
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.actionbar_perfil_personal.*
import kotlinx.android.synthetic.main.activity_perfil_personal.*

class PerfilPersonal : AppCompatActivity() {
    private var paciente = Paciente()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil_personal)
        paciente = intent.getSerializableExtra("paciente") as Paciente
        recuperarPaciente()
        cerrarEditarPerfil.setOnClickListener(View.OnClickListener() {
            MaterialAlertDialogBuilder(this@PerfilPersonal)
                    .setTitle("Descartar cambios")
                    .setMessage("¿Estás seguro que deseas salir? Se descartarán los cambios realizados")
                    .setNegativeButton("Cancelar") { dialog, which ->
                        // Respond to negative button press
                    }
                    .setPositiveButton("Salir") { dialog, which ->
                        this.finish()
                    }
                    .show()
        })
        btnGuardarEdicion.setOnClickListener(View.OnClickListener() {
            MaterialAlertDialogBuilder(this@PerfilPersonal)
                    .setTitle("Guardar cambios")
                    .setMessage("¿Desea guardar cambios?")
                    .setNegativeButton("Cancelar") { dialog, which ->
                        this.finish()
                    }
                    .setPositiveButton("Aceptar") { dialog, which ->
                        compruebaCampos()
                    }
                    .show()
        })
        
    }
    fun compruebaCampos(){
        if(txtEditaNombrePaciente.text.toString().isEmpty() && txtEditaApellidoPaciente.text.toString().isEmpty() && txtEditaFechaNacimientoPaciente.text.toString().isEmpty() &&
        txtEditaGeneroPaciente.text.toString().isEmpty() && txtEditaCorreoPaciente.text.toString().isEmpty() && txtEditaTelefonoPaciente.text.toString().isEmpty() &&
        txtEditaDireccionPaciente.text.toString().isEmpty() && txtEditaContraPaciente.text.toString().isEmpty()){
            MaterialAlertDialogBuilder(this@PerfilPersonal)
                    .setTitle("Campos vacios")
                    .setMessage("Para realizar los cambios no debes dejar campos vacios")
                    .setPositiveButton("Aceptar") { dialog, which ->
                    }
                    .show()
            this.finish()
        }else{
            guardarEdicionPersonal()
        }
    }
    fun guardarEdicionPersonal(){
        Ion.getDefault(this@PerfilPersonal).conscryptMiddleware.enable(false)
        Ion.with(this@PerfilPersonal)
                .load("PUT", "http://192.168.100.4:8084/FitNutritionWS/ws/pacientes/actualizarPaciente")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idPaciente", paciente.idPaciente.toString())
                .setBodyParameter("peso", paciente.peso.toString())
                .setBodyParameter("estatura", paciente.estatura.toString())
                .setBodyParameter("idMedico", paciente.idMedico.toString())
                .setBodyParameter("nombre", txtEditaNombrePaciente.text.toString())
                .setBodyParameter("apellidos", txtEditaApellidoPaciente.text.toString())
                .setBodyParameter("talla", paciente.talla)
                .setBodyParameter("genero", txtEditaGeneroPaciente.text.toString())
                .setBodyParameter("email", txtEditaCorreoPaciente.text.toString())
                .setBodyParameter("telefono", txtEditaTelefonoPaciente.text.toString())
                .setBodyParameter("domicilio", txtEditaDireccionPaciente.text.toString())
                .setBodyParameter("usuario", paciente.usuario)
                .setBodyParameter("contrasena", txtEditaContraPaciente.text.toString())
                .setBodyParameter("fecha_nacimiento", paciente.fecha_nacimiento)
                .setBodyParameter("status", paciente.status)
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@PerfilPersonal, "Error: "+e.message, Toast.LENGTH_LONG).show()
                    }else{
                        val gson = Gson()
                        val msj : Mensaje = gson.fromJson(result, Mensaje::class.java)
                        if(msj.error!!){
                            Toast.makeText(this@PerfilPersonal, msj.mensaje, Toast.LENGTH_LONG).show()
                        }else{
                            MaterialAlertDialogBuilder(this@PerfilPersonal)
                                    .setTitle("Cambio realizado con exito")
                                    .setMessage(msj.mensaje)
                                    .setPositiveButton("Aceptar") { dialog, which ->
                                        txtEditaNombrePaciente.setText("")
                                        txtEditaApellidoPaciente.setText("")
                                        txtEditaFechaNacimientoPaciente.setText("")
                                        txtEditaGeneroPaciente.setText("")
                                        txtEditaCorreoPaciente.setText("")
                                        txtEditaTelefonoPaciente.setText("")
                                        txtEditaDireccionPaciente.setText("")
                                        txtEditaContraPaciente.setText("")
                                        recuperarPaciente()
                                    }
                                    .show()
                        }
                    }
                }
    }

    fun recuperarPaciente(){
        Ion.getDefault(this@PerfilPersonal).conscryptMiddleware.enable(false)
        Ion.with(this@PerfilPersonal)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/pacientes/getPacienteByID")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idPaciente", paciente.idPaciente.toString())
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@PerfilPersonal, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        System.out.println(result)
                        val gson = Gson()
                        paciente= gson.fromJson(result, Paciente::class.java)
                        if(paciente==null){
                            Toast.makeText(this@PerfilPersonal, "Paciente nulo", Toast.LENGTH_LONG).show()
                        }else{
                            txtEditaNombrePaciente.setText(paciente.nombre)
                            txtEditaApellidoPaciente.setText(paciente.apellidos)
                            System.out.println(paciente.fecha_nacimiento)
                            txtEditaFechaNacimientoPaciente.setText(paciente.fecha_nacimiento)
                            txtEditaGeneroPaciente.setText(paciente.genero)
                            txtEditaCorreoPaciente.setText(paciente.email)
                            txtEditaTelefonoPaciente.setText(paciente.telefono)
                            txtEditaDireccionPaciente.setText(paciente.domicilio)
                            txtEditaContraPaciente.setText(paciente.contrasena)
                        }
                    }
                }
    }
}