package com.example.fitnutrition.pojos

import android.os.Parcel
import android.os.Parcelable
import java.io.Serializable
import java.util.*

class Cita() : Serializable, Parcelable{
    val idCita = 0
    var idPaciente:Int = 0
    val observaciones: String = ""
    val fecha: String = ""
    val hora: String = ""
    var usuario: String = ""

    constructor(parcel: Parcel) : this() {
        idPaciente = parcel.readInt()
        usuario = parcel.readString().toString()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(idPaciente)
        parcel.writeString(usuario)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Cita> {
        override fun createFromParcel(parcel: Parcel): Cita {
            return Cita(parcel)
        }

        override fun newArray(size: Int): Array<Cita?> {
            return arrayOfNulls(size)
        }
    }
}