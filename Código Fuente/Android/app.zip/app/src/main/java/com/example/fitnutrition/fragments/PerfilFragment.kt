package com.example.fitnutrition.fragments

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Mensaje
import com.example.fitnutrition.pojos.Paciente
import com.example.fitnutrition.util.PerfilNutricional
import com.example.fitnutrition.util.PerfilPersonal
import com.example.fitnutrition.util.PerfilSubeFoto
import kotlinx.android.synthetic.main.fragment_perfil.*
import kotlinx.android.synthetic.main.fragment_perfil.view.*
import java.io.File


@Suppress("UNREACHABLE_CODE")
class PerfilFragment : Fragment() {
    private var paciente = Paciente()
    private var mensaje = Mensaje()
    private var activity : Activity? = null
    private lateinit var txtNombrePerfil : TextView
    private lateinit var txtEstaturaPerfil : TextView
    private lateinit var txtPesoPerfil : TextView
    private lateinit var txtIMCPerfil : TextView
    private lateinit var imgPerfil : ImageView
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var v : View = inflater.inflate(R.layout.fragment_perfil, container, false)
        activity= this.getActivity()
        var bundle : Bundle? = this.getArguments()
        paciente = bundle?.getSerializable("paciente") as Paciente
        mensaje = bundle?.getSerializable("mensaje") as Mensaje
        System.out.println(paciente.nombre)
        val rlInfPersonalPerfil = v.findViewById<RelativeLayout>(R.id.rlInfPersonalPerfil)
        txtNombrePerfil = v.findViewById(R.id.txtNombrePerfil)
        txtEstaturaPerfil = v.findViewById(R.id.txtEstaturaPerfil)
        txtPesoPerfil = v.findViewById(R.id.txtPesoPerfil)
        txtIMCPerfil = v.findViewById(R.id.txtIMCPerfil)
        imgPerfil = v.findViewById(R.id.imgPerfil)
        rlInfPersonalPerfil.setOnClickListener(View.OnClickListener {
            val intent = Intent(activity, PerfilPersonal::class.java)
            intent.putExtra("paciente", paciente)
            startActivity(intent)
        })
        v.rlInfNutricionalPerfil.setOnClickListener(View.OnClickListener {
            val intent = Intent(activity, PerfilNutricional::class.java)
            intent.putExtra("paciente", paciente)
            startActivity(intent)
        })
        v.rlSubirImgPerfil.setOnClickListener(View.OnClickListener {
            val intent = Intent(activity, PerfilSubeFoto::class.java)
            intent.putExtra("paciente", paciente)
            startActivity(intent)
        })
        cargaPaciente()
        cargaFoto()
        return v
    }

    fun cargaPaciente(){
        txtNombrePerfil.text= "Hola " + paciente.nombre + " " + paciente.apellidos
        txtEstaturaPerfil.text = "Estatura " + paciente.estatura
        txtPesoPerfil.text= "Peso " + paciente.peso
        var imc: Double= (paciente.peso.div((paciente.estatura.toDouble()).div(100) * (paciente.estatura.toDouble()).div(100)))
        txtIMCPerfil.text= "IMC " + String.format("%.2f", imc)
    }

    fun cargaFoto(){
        var fileImg = File(mensaje.mensaje)
        try{
            val myBitmap = BitmapFactory.decodeFile(fileImg.getAbsolutePath())
            imgPerfil.setImageBitmap(myBitmap)
        }catch (e: Exception){

        }
    }
}