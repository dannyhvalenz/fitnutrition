package com.example.fitnutrition.util

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Mensaje
import com.google.gson.Gson
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    private var id = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnLogin.setOnClickListener {
            validaCampos()
        }
    }

    fun validaCampos(){
        val usuario = tfUsuario.text.toString()
        val contra = tfContra.text.toString()
        var isValido = true

        if(usuario.isEmpty()){
            isValido = false
            lyUsuario.error = "Debes introducir un usuario"
        }
        if(contra.isEmpty()){
            isValido = false
            lyContra.error = "Debes introducir una contraseña"
        }
        if(isValido){
            lyUsuario.isErrorEnabled = false
            lyContra.isErrorEnabled = false
            loginWS(usuario, contra)
        }
    }

    fun loginWS(usuario : String, contra : String){
        Ion.getDefault(this@MainActivity).conscryptMiddleware.enable(false)
        Ion.with(this@MainActivity)
            .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/sesion/login")
            .setHeader("Content-Type", "application/x-www-form-urlencoded")
            .setBodyParameter("usuario", usuario)
            .setBodyParameter("contrasena", contra)
            .asString()
            .setCallback { e, result ->
                if(e != null){
                    e.printStackTrace()
                    Toast.makeText(this@MainActivity, "Error: "+e.message, Toast.LENGTH_LONG).show()
                }else{
                    val gson = Gson()
                    val msj : Mensaje = gson.fromJson(result, Mensaje::class.java)
                    if(msj.error!!){
                        Toast.makeText(this@MainActivity, ""+msj.mensaje, Toast.LENGTH_LONG).show()
                    }else{
                        id = msj.mensaje.substring(11)
                        Toast.makeText(this@MainActivity, "Bienvenido", Toast.LENGTH_LONG).show()
                        irPrincipal()
                    }
                }
            }
    }
    fun irPrincipal(){
        startActivity(Intent(this@MainActivity, Principal::class.java).putExtra("idPaciente", id))
        this.finish()
    }
}