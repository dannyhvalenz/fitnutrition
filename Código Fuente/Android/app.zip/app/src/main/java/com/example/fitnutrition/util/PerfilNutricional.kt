package com.example.fitnutrition.util

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnutrition.R
import com.example.fitnutrition.adaptador.AdaptadorListaConsulta
import com.example.fitnutrition.pojos.Consulta
import com.example.fitnutrition.pojos.Dieta
import com.example.fitnutrition.pojos.Paciente
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.activity_perfil_nutricional.*
import kotlinx.android.synthetic.main.fragment_citas.*

class PerfilNutricional : AppCompatActivity() {
    private var paciente = Paciente()
    private var consulta = Consulta()
    private var dieta = Dieta()
    private var consultas = ArrayList<Consulta>()
    private lateinit var cerrarEditarPerfilNutricional : ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil_nutricional)
        cerrarEditarPerfilNutricional = findViewById(R.id.cerrarEditarPerfilNutricional)
        paciente = intent.getSerializableExtra("paciente") as Paciente
        recuperarConsulta()
        cerrarEditarPerfilNutricional.setOnClickListener(View.OnClickListener {
            this.finish()
        })
    }
    fun recuperarConsulta(){
            Ion.getDefault(this@PerfilNutricional).conscryptMiddleware.enable(false)
            Ion.with(this@PerfilNutricional)
                    .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/consultas/getConsultaByIDPaciente")
                    .setHeader("Content-Type", "application/x-www-form-urlencoded")
                    .setBodyParameter("idPaciente", paciente.idPaciente.toString())
                    .asString()
                    .setCallback { e, result ->
                        if(e != null){
                            e.printStackTrace()
                            Toast.makeText(this@PerfilNutricional, "Error: " + e.message, Toast.LENGTH_LONG).show()
                        }else{
                            //Log.d("idPaciente", idPaciente)
                            Log.d("Respuesta WS", result)
                            val gson = Gson()
                            consulta= gson.fromJson(result, Consulta::class.java)
                            if(consulta==null){
                                Toast.makeText(this@PerfilNutricional, "No existen consultas agendadas", Toast.LENGTH_LONG).show()
                            }else{
                                txtPesoPerfilNutricional.text = consulta.peso.toString() + " kg"
                                txtAlturaPerfilNutricional.text = paciente.estatura.toString() + " cm"
                                txtIMCPerfilNutricional.text = consulta.imc.toString()
                                txtComentarioPerfilNutricional.text = consulta.observaciones
                                recuperarDieta()
                            }
                        }
                    }
    }

    fun recuperarDieta(){
        Ion.getDefault(this@PerfilNutricional).conscryptMiddleware.enable(false)
        Ion.with(this@PerfilNutricional)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/dietas/getDietaByID")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idDieta", consulta.idDieta.toString())
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@PerfilNutricional, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS 1", result)
                        val gson = Gson()
                        dieta= gson.fromJson(result, Dieta::class.java)
                        if(dieta==null){
                            Toast.makeText(this@PerfilNutricional, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                        }else{
                            txtDietaPerfilNutricional.text = dieta.nombre
                            recuperarConsultasAnteriores()
                        }
                    }
                }
    }

    fun recuperarConsultasAnteriores(){
        Ion.getDefault(this@PerfilNutricional).conscryptMiddleware.enable(false)
        Ion.with(this@PerfilNutricional)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/consultas/getConsultasOfPaciente")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idPaciente", paciente.idPaciente.toString())
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@PerfilNutricional, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        val gson = Gson()
                        val arrType = object: TypeToken<ArrayList<Consulta>>(){}.type
                        consultas = gson.fromJson(result, arrType)
                        if(dieta==null){
                            Toast.makeText(this@PerfilNutricional, "No se encontró la dieta", Toast.LENGTH_LONG).show()
                        }else{
                            listarConsultas()
                        }
                    }
                }
    }
    fun listarConsultas(){
        val adaptadorListaConsulta = AdaptadorListaConsulta(paciente.estatura.toString(), consulta.idConsulta)
        adaptadorListaConsulta.consultas = consultas
        val layoutManager = LinearLayoutManager(this@PerfilNutricional)
        rvConsultaAnterior.layoutManager = layoutManager
        rvConsultaAnterior.adapter = adaptadorListaConsulta
    }
}