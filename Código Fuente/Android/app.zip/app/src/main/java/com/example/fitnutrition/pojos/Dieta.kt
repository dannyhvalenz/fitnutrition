package com.example.fitnutrition.pojos

class Dieta {
    val idDieta = 0
    var idAlimento:Int = 0
    val nombre: String = ""
    var horaDia:String = ""
    var observaciones:String = ""
    var cantidad:kotlin.String = ""
    val caloriasDieta = 0f
}