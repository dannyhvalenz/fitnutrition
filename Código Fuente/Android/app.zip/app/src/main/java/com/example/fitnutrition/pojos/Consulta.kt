package com.example.fitnutrition.pojos

class Consulta {
    val idConsulta = 0
    var idPaciente:Int = 0
    var idDieta:Int = 0
    val peso = 0f
    var imc:Float = 0f
    val observaciones: String = ""
    var talla:String = ""
}