package com.example.fitnutrition.adaptador

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Alimento
import com.example.fitnutrition.pojos.Cita
import com.example.fitnutrition.pojos.Dieta
import com.google.gson.Gson
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.fragment_dietas.*

class AdaptadorListaDieta (nombres : ArrayList<String>, nombre : String, activity : Activity?): RecyclerView.Adapter<AdaptadorListaDieta.ViewHolder>(){
    var activity = activity
    var nombre = nombre
    var nombres = nombres
    var alimento = Alimento()
    var dietas = ArrayList<Dieta>()
        set(value) {
            field = value
        }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val card = LayoutInflater.from(parent.context).inflate(R.layout.adapter_lista_otras_dietas, parent, false)
        return ViewHolder(card)
    }

    override fun getItemCount(): Int {
        return dietas.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val diet = dietas.get(position)
        for(i in 0.. nombres.size.minus(1)){
            if(diet.nombre.equals(nombre)){
                holder.cvOtraDieta.visibility=View.GONE
            }else{
                if(diet.nombre.equals(nombres[i])){
                    if(diet.horaDia.equals("Desayuno")){
                        holder.txtNombreDietaAnterior.text = diet.nombre + " (Desayuno)"
                        Ion.getDefault(activity).conscryptMiddleware.enable(false)
                        Ion.with(activity)
                                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/alimentos/getAlimentoByID")
                                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                                .setBodyParameter("idAlimento", diet.idAlimento.toString())
                                .asString()
                                .setCallback { e, result ->
                                    if(e != null){
                                        e.printStackTrace()
                                        Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                                    }else{
                                        val gson = Gson()
                                        alimento= gson.fromJson(result, Alimento::class.java)
                                        if(alimento==null){
                                            Toast.makeText(activity, "No se encontró el alimento", Toast.LENGTH_LONG).show()
                                        }else{
                                            holder.txtNombreComidaDesayunoAnterior.text = alimento.nombre
                                            holder.txtCantidadDesayunoAnterior.text = diet.cantidad
                                            holder.txtCaloriasDesayunoAnterior.text = diet.caloriasDieta.toString()
                                            holder.txtObsDesayunoAnterior.text = diet.observaciones
                                            holder.lyComidaDietaAnterior.visibility = View.GONE
                                            holder.lyCenaDietaAnterior.visibility = View.GONE
                                        }
                                    }
                                }
                    }
                    if(diet.horaDia.equals("Comida")){
                        holder.txtNombreDietaAnterior.text = diet.nombre + " (Comida)"
                        Ion.getDefault(activity).conscryptMiddleware.enable(false)
                        Ion.with(activity)
                                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/alimentos/getAlimentoByID")
                                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                                .setBodyParameter("idAlimento", diet.idAlimento.toString())
                                .asString()
                                .setCallback { e, result ->
                                    if(e != null){
                                        e.printStackTrace()
                                        Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                                    }else{
                                        val gson = Gson()
                                        alimento= gson.fromJson(result, Alimento::class.java)
                                        if(alimento==null){
                                            Toast.makeText(activity, "No se encontró el alimento", Toast.LENGTH_LONG).show()
                                        }else{
                                            holder.txtNombreComidaComidaAnterior.text = alimento.nombre
                                            holder.txtCantidadComidaAnterior.text = diet.cantidad
                                            holder.txtCaloriasComidaAnterior.text = diet.caloriasDieta.toString()
                                            holder.txtObsComidaAnterior.text = diet.observaciones
                                            holder.lyDesayunoDietaAnterior.visibility = View.GONE
                                            holder.lyCenaDietaAnterior.visibility = View.GONE
                                        }
                                    }
                                }
                    }
                    if(diet.horaDia.equals("Cena")){
                        holder.txtNombreDietaAnterior.text = diet.nombre + " (Cena)"
                        Ion.getDefault(activity).conscryptMiddleware.enable(false)
                        Ion.with(activity)
                                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/alimentos/getAlimentoByID")
                                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                                .setBodyParameter("idAlimento", diet.idAlimento.toString())
                                .asString()
                                .setCallback { e, result ->
                                    if(e != null){
                                        e.printStackTrace()
                                        Toast.makeText(activity, "Error: " + e.message, Toast.LENGTH_LONG).show()
                                    }else{
                                        val gson = Gson()
                                        alimento= gson.fromJson(result, Alimento::class.java)
                                        if(alimento==null){
                                            Toast.makeText(activity, "No se encontró el alimento", Toast.LENGTH_LONG).show()
                                        }else{
                                            holder.txtNombreComidaCenaAnterior.text = alimento.nombre
                                            holder.txtCantidadCenaAnterior.text = diet.cantidad
                                            holder.txtCaloriasCenaAnterior.text = diet.caloriasDieta.toString()
                                            holder.txtObsCenaAnterior.text = diet.observaciones
                                            holder.lyComidaDietaAnterior.visibility = View.GONE
                                            holder.lyDesayunoDietaAnterior.visibility = View.GONE
                                        }
                                    }
                                }
                    }
                }
            }
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var txtNombreDietaAnterior : TextView
        var txtNombreComidaDesayunoAnterior : TextView
        var txtCantidadDesayunoAnterior : TextView
        var txtCaloriasDesayunoAnterior : TextView
        var txtObsDesayunoAnterior : TextView

        var txtNombreComidaComidaAnterior : TextView
        var txtCantidadComidaAnterior : TextView
        var txtCaloriasComidaAnterior : TextView
        var txtObsComidaAnterior : TextView

        var txtNombreComidaCenaAnterior : TextView
        var txtCantidadCenaAnterior : TextView
        var txtCaloriasCenaAnterior : TextView
        var txtObsCenaAnterior : TextView


        var btnOcultarDetalleDietaAnterior : ImageButton
        var btnMuestraDetalleDietaAnterior : ImageButton
        lateinit var lyComidasDietaAnterior : LinearLayout

        lateinit var lyTxtDetallesDietaAnterior : LinearLayout
        lateinit var lyDesayunoDietaAnterior : LinearLayout
        lateinit var lyComidaDietaAnterior : LinearLayout
        lateinit var lyCenaDietaAnterior : LinearLayout

        lateinit var cvOtraDieta : CardView
        init {
            txtNombreDietaAnterior = itemView.findViewById(R.id.txtNombreDietaAnterior)
            txtNombreComidaDesayunoAnterior = itemView.findViewById(R.id.txtNombreComidaDesayunoAnterior)
            txtCantidadDesayunoAnterior = itemView.findViewById(R.id.txtCantidadDesayunoAnterior)
            txtCaloriasDesayunoAnterior = itemView.findViewById(R.id.txtCaloriasDesayunoAnterior)
            txtObsDesayunoAnterior = itemView.findViewById(R.id.txtObsDesayunoAnterior)

            txtNombreComidaComidaAnterior = itemView.findViewById(R.id.txtNombreComidaComidaAnterior)
            txtCantidadComidaAnterior = itemView.findViewById(R.id.txtCantidadComidaAnterior)
            txtCaloriasComidaAnterior = itemView.findViewById(R.id.txtCaloriasComidaAnterior)
            txtObsComidaAnterior = itemView.findViewById(R.id.txtObsComidaAnterior)

            txtNombreComidaCenaAnterior = itemView.findViewById(R.id.txtNombreComidaCenaAnterior)
            txtCantidadCenaAnterior = itemView.findViewById(R.id.txtCantidadCenaAnterior)
            txtCaloriasCenaAnterior = itemView.findViewById(R.id.txtCaloriasCenaAnterior)
            txtObsCenaAnterior = itemView.findViewById(R.id.txtObsCenaAnterior)


            btnMuestraDetalleDietaAnterior = itemView.findViewById(R.id.btnMuestraDetalleDietaAnterior)
            btnOcultarDetalleDietaAnterior = itemView.findViewById(R.id.btnOcultarDetalleDietaAnterior)

            lyComidasDietaAnterior = itemView.findViewById(R.id.lyComidasDietaAnterior)
            lyDesayunoDietaAnterior = itemView.findViewById(R.id.lyDesayunoDietaAnterior)
            lyComidaDietaAnterior = itemView.findViewById(R.id.lyComidaDietaAnterior)
            lyCenaDietaAnterior = itemView.findViewById(R.id.lyCenaDietaAnterior)

            cvOtraDieta = itemView.findViewById(R.id.cvOtraDieta)

            lyTxtDetallesDietaAnterior = itemView.findViewById(R.id.lyTxtDetallesDietaAnterior)
            btnMuestraDetalleDietaAnterior.setOnClickListener(View.OnClickListener{
                lyComidasDietaAnterior.visibility = View.VISIBLE
                lyTxtDetallesDietaAnterior.visibility = View.VISIBLE
                btnOcultarDetalleDietaAnterior.visibility = View.VISIBLE
                btnMuestraDetalleDietaAnterior.visibility = View.GONE
            })
            btnOcultarDetalleDietaAnterior.setOnClickListener(View.OnClickListener{
                lyComidasDietaAnterior.visibility = View.GONE
                lyTxtDetallesDietaAnterior.visibility = View.GONE
                btnMuestraDetalleDietaAnterior.visibility = View.VISIBLE
                btnOcultarDetalleDietaAnterior.visibility = View.GONE
            })
        }
    }
}