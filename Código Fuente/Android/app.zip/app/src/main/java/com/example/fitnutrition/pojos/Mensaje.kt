package com.example.fitnutrition.pojos

import java.io.Serializable

class Mensaje : Serializable {
    var error : Boolean? = null
    var mensaje : String = ""
}