package com.example.fitnutrition.adaptador

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Consulta

class AdaptadorListaConsulta (estatura: String, idConsulta: Int) : RecyclerView.Adapter<AdaptadorListaConsulta.ViewHolder>(){
    var estatura = estatura
    var idConsulta = idConsulta
    var consultas = ArrayList<Consulta>()
        set(value) {
            field = value
        }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val card = LayoutInflater.from(parent.context).inflate(R.layout.adapter_lista_consultas, parent, false)
        return ViewHolder(card)
    }

    override fun getItemCount(): Int {
        return consultas.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val con = consultas.get(position)
        if(con.idConsulta.equals(idConsulta)){
            holder.cvConsultasAnteriores.visibility = View.GONE
        }else{
            holder.txtPesoConsultaAnterior.text = "Peso: " + con.peso + " kg"
            holder.txtAlturaConsultaAnterior.text = "Estatura" + estatura + " cm"
            holder.txtIMCConsulraAnterior.text = "Hora: " + con.imc
            holder.txtComentarioConsultaAnterior.text = "Comentarios: " + con.observaciones
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var cvConsultasAnteriores : CardView
        var txtPesoConsultaAnterior : TextView
        var txtAlturaConsultaAnterior : TextView
        var txtIMCConsulraAnterior : TextView
        var txtComentarioConsultaAnterior : TextView
        var txtDetalleConsultaAnterior : TextView
        var btnOcultarDetalleConsultaAnterior : ImageButton
        var btnMuestraDetalleConsultaAnterior : ImageButton
        lateinit var lyInfoComentariosConsultaAnterior : LinearLayout
        lateinit var lyTxtDetallesConsultaAnterior : LinearLayout
        init {
            cvConsultasAnteriores = itemView.findViewById(R.id.cvConsultasAnteriores)
            txtPesoConsultaAnterior = itemView.findViewById(R.id.txtPesoConsultaAnterior)
            txtAlturaConsultaAnterior = itemView.findViewById(R.id.txtAlturaConsultaAnterior)
            txtIMCConsulraAnterior = itemView.findViewById(R.id.txtIMCConsultaAnterior)
            txtDetalleConsultaAnterior = itemView.findViewById(R.id.txtDetalleConsultaAnterior)
            txtComentarioConsultaAnterior = itemView.findViewById(R.id.txtComentarioConsultaAnterior)
            btnMuestraDetalleConsultaAnterior = itemView.findViewById(R.id.btnMuestraDetalleConsultaAnterior)
            btnOcultarDetalleConsultaAnterior = itemView.findViewById(R.id.btnOcultarDetalleConsultaAnterior)
            lyInfoComentariosConsultaAnterior = itemView.findViewById(R.id.lyInfoComentariosConsultaAnterior)
            lyTxtDetallesConsultaAnterior = itemView.findViewById(R.id.lyTxtDetallesConsultaAnterior)
            btnMuestraDetalleConsultaAnterior.setOnClickListener(View.OnClickListener{
                lyInfoComentariosConsultaAnterior.visibility = View.VISIBLE
                lyTxtDetallesConsultaAnterior.visibility = View.VISIBLE
                btnOcultarDetalleConsultaAnterior.visibility = View.VISIBLE
                btnMuestraDetalleConsultaAnterior.visibility = View.GONE
                txtDetalleConsultaAnterior.visibility = View.GONE
            })
            btnOcultarDetalleConsultaAnterior.setOnClickListener(View.OnClickListener{
                lyInfoComentariosConsultaAnterior.visibility = View.GONE
                lyTxtDetallesConsultaAnterior.visibility = View.GONE
                btnOcultarDetalleConsultaAnterior.visibility = View.GONE
                btnMuestraDetalleConsultaAnterior.visibility = View.VISIBLE
                txtDetalleConsultaAnterior.visibility = View.VISIBLE
            })
        }
    }
}