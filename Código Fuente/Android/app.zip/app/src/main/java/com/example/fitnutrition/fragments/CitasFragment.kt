package com.example.fitnutrition.fragments

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnutrition.R
import com.example.fitnutrition.adaptador.AdaptadorListaCita
import com.example.fitnutrition.pojos.Cita
import com.example.fitnutrition.pojos.Mensaje
import com.example.fitnutrition.util.Principal
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.fragment_citas.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class CitasFragment : Fragment() {
    private lateinit var txtDetalleCita : TextView
    private lateinit var txtOcultaDetalleCita : TextView
    private lateinit var txtFechaCita : TextView
    private lateinit var txtHoraCita : TextView
    private lateinit var txtDoctorCita : TextView
    private lateinit var txtComentariosCita : TextView
    private lateinit var cvCitaCancelada : CardView
    private lateinit var cvCitaProxima : CardView
    private lateinit var btnCancelaCita : Button
    private lateinit var btnOrdenaLista : ImageButton
    private var citas = ArrayList<Cita>()
    private var nombreMedico : String? = null
    private var idPaciente : String? = null
    private var cita : Cita? = null
    private var activity : Activity? = null
    private var mensaje = Mensaje()
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var v : View = inflater.inflate(R.layout.fragment_citas, container, false)
        activity = this.getActivity()
        val bundle:Bundle? = this.getArguments()
        idPaciente = bundle?.getString("paciente")
        cita = bundle?.getSerializable("cita") as Cita?
        nombreMedico = bundle?.getString("medico")
        txtDetalleCita = v.findViewById<TextView>(R.id.txtDetalleCita)
        txtOcultaDetalleCita = v.findViewById<TextView>(R.id.txtOcultaDetalleCita)
        txtFechaCita = v.findViewById<TextView>(R.id.txtFechaCita)
        txtHoraCita = v.findViewById<TextView>(R.id.txtHoraCita)
        txtDoctorCita = v.findViewById<TextView>(R.id.txtDoctorCita)
        txtComentariosCita = v.findViewById<TextView>(R.id.txtComentariosCita)
        cvCitaCancelada = v.findViewById(R.id.cvCitaCancelada)
        cvCitaProxima = v.findViewById(R.id.cvCitaProxima)
        btnCancelaCita = v.findViewById(R.id.btnCancelaCita)
        btnOrdenaLista = v.findViewById(R.id.btnOrdenaLista)
        txtDetalleCita.setOnClickListener(View.OnClickListener{
            llVerDetalles.visibility = View.VISIBLE
            txtDetalleCita.visibility = View.GONE
        })
        txtOcultaDetalleCita.setOnClickListener(View.OnClickListener{
            llVerDetalles.visibility = View.GONE
            txtDetalleCita.visibility = View.VISIBLE
        })
        llenarCita()
        recuperarCitas()
        btnCancelaCita.setOnClickListener(View.OnClickListener {
            comprobarFechas()
        })
        btnOrdenaLista.setOnClickListener (View.OnClickListener{
            val singleItems = arrayOf("Mas reciente", "Mas antiguo")
            val checkedItem = 0
            activity?.let { it1 ->

                MaterialAlertDialogBuilder(activity as FragmentActivity)
                        .setTitle("Ordenar citas por fecha")
                        .setNeutralButton("Cancelar") { dialog, which ->
                            // Respond to neutral button press
                        }
                        .setPositiveButton("Aceptar") { dialog, which ->

                        }
                        .setSingleChoiceItems(singleItems, checkedItem) { dialog, which ->
                            if(singleItems[which].equals("Mas reciente")){
                                Ion.with(activity)
                                        .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/getAllCitasDesc")
                                        .asString()
                                        .setCallback{e, result ->
                                            if(e!=null){
                                                e.printStackTrace()
                                                Toast.makeText(activity, e.message, Toast.LENGTH_LONG).show()
                                            }else{
                                                Log.d("Respuesta WS", result)
                                                val gson = Gson()
                                                val arrType = object: TypeToken<ArrayList<Cita>>(){}.type
                                                citas = gson.fromJson(result, arrType)
                                                cargarCitasAnteriores();
                                            }
                                        }
                            }
                            if(singleItems[which].equals("Mas antiguo")){
                                Ion.with(activity)
                                        .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/getAllCitasAsc")
                                        .asString()
                                        .setCallback{e, result ->
                                            if(e!=null){
                                                e.printStackTrace()
                                                Toast.makeText(activity, e.message, Toast.LENGTH_LONG).show()
                                            }else{
                                                Log.d("Respuesta WS", result)
                                                val gson = Gson()
                                                val arrType = object: TypeToken<ArrayList<Cita>>(){}.type
                                                citas = gson.fromJson(result, arrType)
                                                cargarCitasAnteriores();
                                            }
                                        }
                            }
                        }
                        .show()
            }
        })
        return v
    }
    fun llenarCita(){
        txtFechaCita.text = "Fecha: " + cita?.fecha.toString()
        txtHoraCita.text = "Hora: " + cita?.hora
        txtDoctorCita.text = "Medico: " + nombreMedico
        txtComentariosCita.text = "Obsevaciones: " + cita?.observaciones
    }

    fun recuperarCitas(){
        Ion.with(activity)
                .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/getAllCitas")
                .asString()
                .setCallback{e, result ->
                    if(e!=null){
                        e.printStackTrace()
                        Toast.makeText(activity, e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        val arrType = object: TypeToken<ArrayList<Cita>>(){}.type
                        citas = gson.fromJson(result, arrType)
                        cargarCitasAnteriores();
                    }
                }
    }

    fun cargarCitasAnteriores(){
        val adaptadorListaCita = AdaptadorListaCita(idPaciente.toString(), cita?.fecha.toString())
        adaptadorListaCita.citas = citas
        val layoutManager = LinearLayoutManager(activity)
        rvlistaCitaAnterior.layoutManager = layoutManager
        rvlistaCitaAnterior.adapter = adaptadorListaCita
    }

    fun comprobarFechas(){
        val sdf = SimpleDateFormat("yyyy/MM/dd")
        System.out.println("Curren sdf" + sdf)
        val currentDate = sdf.format(Date())
        System.out.println("Fecha current" + currentDate)
        val diaActual = currentDate.toString().substring(8,10).toInt()
        val mesActual = currentDate.toString().substring(5, 7).toInt()
        val anioActual = currentDate.toString().substring(0, 4).toInt()
        val diaCita = cita?.fecha.toString().substring(8, 10).toInt()
        val mesCita = cita?.fecha.toString().substring(5, 7).toInt()
        val anioCita = cita?.fecha.toString().substring(0, 4).toInt()
        System.out.println("dia"+ diaActual + "mes" + mesActual + "año" + anioActual)
        if(diaActual < diaCita && mesActual <= mesCita && anioActual <= anioCita){
            activity?.let {
                MaterialAlertDialogBuilder(it)
                        .setTitle("Cancelar cita")
                        .setMessage("¿Estás seguro que deseas cancelar la cita?")
                        .setNegativeButton("Cancelar") { dialog, which ->
                            // Respond to negative button press
                        }
                        .setPositiveButton("Aceptar") { dialog, which ->
                            Ion.with(activity)
                                    .load("DELETE", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/eliminarCita")
                                    .setHeader("Content-Type", "application/x-www-form-urlencoded")
                                    .setBodyParameter("idCita", cita?.idCita.toString())
                                    .asString()
                                    .setCallback{e, result ->
                                        if(e!=null){
                                            e.printStackTrace()
                                            Toast.makeText(activity, e.message, Toast.LENGTH_LONG).show()
                                        }else{
                                            Log.d("Respuesta WS", result)
                                            val gson = Gson()
                                            mensaje = gson.fromJson(result ,Mensaje::class.java)
                                            if(mensaje.error?.equals(false) == true){
                                                cvCitaCancelada.visibility = View.VISIBLE
                                                cvCitaProxima.visibility = View.GONE
                                                recuperarCitas()
                                                MaterialAlertDialogBuilder(activity!!)
                                                        .setTitle("Cita cancelada")
                                                        .setMessage("La cita ha sido cancelada con éxito")
                                                        .setPositiveButton("Aceptar") { dialog, which ->

                                                        }
                                                        .show()
                                            }else{
                                                MaterialAlertDialogBuilder(activity!!)
                                                        .setTitle("Cita no cancelada")
                                                        .setMessage("La cita no ha podido ser cancelada")
                                                        .setPositiveButton("Aceptar") { dialog, which ->

                                                        }
                                                        .show()
                                            }
                                        }
                                    }
                        }
                        .show()
            }
        }else{

        }
    }

}