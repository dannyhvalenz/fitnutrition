package com.example.fitnutrition.pojos

import java.io.Serializable

class Paciente : Serializable {
    val idPaciente:Int = 0
    var estatura:Int = 0
    var idMedico:Int = 0
    var peso:Float = 0f
    var nombre: String = ""
    var apellidos:String = ""
    var talla:String = ""
    var genero:String = ""
    var email:String = ""
    var telefono:String = ""
    var domicilio:String = ""
    var usuario:String = ""
    var contrasena:String = ""
    var status:String = ""
    var fecha_nacimiento:String = ""
    val fotografia: ByteArray
        get() {
            TODO()
        }
}