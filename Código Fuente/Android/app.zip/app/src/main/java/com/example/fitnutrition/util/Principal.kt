package com.example.fitnutrition.util

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnutrition.R
import com.example.fitnutrition.adaptador.AdaptadorListaCita
import com.example.fitnutrition.fragments.CitasFragment
import com.example.fitnutrition.fragments.DietasFragment
import com.example.fitnutrition.fragments.PerfilFragment
import com.example.fitnutrition.pojos.Cita
import com.example.fitnutrition.pojos.Medico
import com.example.fitnutrition.pojos.Mensaje
import com.example.fitnutrition.pojos.Paciente
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.koushikdutta.ion.Ion
import kotlinx.android.synthetic.main.fragment_citas.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class Principal : AppCompatActivity() {
    private var idPaciente = ""
    private var idMedico = ""
    private var paciente = Paciente()
    private var medico = Medico()
    private var cita = Cita()
    private var fotoPraciente = ""
    private var citas = ArrayList<Cita>()
    private var mensaje = Mensaje()
    private lateinit var txtDetalleCita : TextView
    private lateinit var txtOcultaDetalleCita : TextView
    private lateinit var view : View
    private lateinit var btnCancelaCita : MaterialButton
    lateinit var btnOrdenaLista : ImageButton
    override fun onCreate(savedInstanceState: Bundle?) {
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)
        //setContentView(R.layout.fragment_citas)
        idPaciente = intent.getStringExtra("idPaciente")
        recuperarPaciente()
        cargarFoto()
        //saberFecha()
        //recuperarFoto()
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        bottomNavigationView.setOnNavigationItemSelectedListener(navigationItemSelectedListener)
        supportFragmentManager.beginTransaction().replace(R.id.idFragments, CitasFragment()).commit()
    }
    private val navigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        var selectedFragment: Fragment? = null
        when (item.itemId) {
            R.id.ic_citas -> {
                selectedFragment = CitasFragment()
                val bundle = Bundle()
                bundle.putString("paciente", idPaciente)
                bundle.putSerializable("cita", cita)
                bundle.putString("medico", medico.nombre + " " +medico.apellidos)
                selectedFragment.setArguments(bundle)
            }
            R.id.ic_dietas -> {
                selectedFragment = DietasFragment()
                val bundle = Bundle()
                bundle.putString("paciente", idPaciente)
                selectedFragment.setArguments(bundle)
            }
            R.id.ic_perfil -> {
                selectedFragment = PerfilFragment()
                val bundle = Bundle()
                bundle.putSerializable("paciente", paciente)
                bundle.putSerializable("mensaje", mensaje)
                selectedFragment.setArguments(bundle)
            }
        }
        supportFragmentManager.beginTransaction().replace(R.id.idFragments, selectedFragment!!).commit()
        true
    }

    fun recuperarPaciente(){
        Ion.getDefault(this@Principal).conscryptMiddleware.enable(false)
        Ion.with(this@Principal)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/pacientes/getPacienteByID")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idPaciente", idPaciente)
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@Principal, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        System.out.println(result)
                        val gson = Gson()
                        paciente= gson.fromJson(result, Paciente::class.java)
                        if(paciente==null){
                            Toast.makeText(this@Principal, "Paciente nulo", Toast.LENGTH_LONG).show()
                        }else{
                            System.out.println(paciente.nombre + " " +paciente.apellidos)
                            idMedico = paciente.idMedico.toString()
                            recuperarDoctor()
                        }
                    }
                }
    }

    fun recuperarDoctor(){
        Ion.getDefault(this@Principal).conscryptMiddleware.enable(false)
        Ion.with(this@Principal)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/medicos/getMedicoByID")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idMedico", idMedico)
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@Principal, "Error: " + e.message, Toast.LENGTH_LONG).show()
                    }else{
                        System.out.println(result + "AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH")
                        val gson = Gson()
                        medico= gson.fromJson(result, Medico::class.java)
                        if(paciente==null){
                            Toast.makeText(this@Principal, "Medico nulo", Toast.LENGTH_LONG).show()
                        }else{
                            System.out.println("Médico" + medico.nombre)
                            recuperarUltimaCita()
                        }
                    }
                }
    }

    fun recuperarUltimaCita(){
        Ion.with(this@Principal)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/getUltimaCitaByPaciente")
                .setHeader("Content-Type", "application/x-www-form-urlencoded")
                .setBodyParameter("idPaciente", idPaciente)
                .asString()
                .setCallback{e, result ->
                    if(e!=null){
                        e.printStackTrace()
                        Toast.makeText(this@Principal, e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        cita = gson.fromJson(result, Cita::class.java)
                        if(cita==null){
                            Toast.makeText(this@Principal, "Cita nula", Toast.LENGTH_LONG).show()
                        }else{
                            llenarCita()
                            recuperarCitas()
                        }
                    }
                }
    }

    fun recuperarCitas(){
        Ion.with(this@Principal)
                .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/getAllCitas")
                .asString()
                .setCallback{e, result ->
                    if(e!=null){
                        e.printStackTrace()
                        Toast.makeText(this@Principal, e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        val arrType = object: TypeToken<ArrayList<Cita>>(){}.type
                        citas = gson.fromJson(result, arrType)
                        cargarCitasAnteriores();
                    }
                }
    }

    fun cargarCitasAnteriores(){
        System.out.println("Fechaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + cita.fecha)
        val adaptadorAerolinea = AdaptadorListaCita(paciente.idPaciente.toString(), cita.fecha)
        adaptadorAerolinea.citas = citas
        val layoutManager = LinearLayoutManager(this@Principal)
        rvlistaCitaAnterior.layoutManager = layoutManager
        rvlistaCitaAnterior.adapter = adaptadorAerolinea
    }

    fun llenarCita(){
        txtFechaCita.text = "Fecha: " + cita.fecha
        txtHoraCita.text = "Hora: " + cita.hora
        txtDoctorCita.text = "Medico: " + medico.nombre + " " + medico.apellidos
        txtComentariosCita.text = "Obsevaciones: " + cita.observaciones
    }

    fun cargarFoto(){
        System.out.println("HOLAHOLA" + idPaciente)
        Ion.with(this@Principal)
                .load("GET", "http://192.168.100.4:8084/FitNutritionWS/ws/pacientes/getFotografiaPaciente/"+idPaciente)
                .asString()
                .setCallback{e, result ->
                    if(e!=null){
                        e.printStackTrace()
                        Toast.makeText(this@Principal, e.message, Toast.LENGTH_LONG).show()
                    }else{
                        Log.d("Respuesta WS", result)
                        val gson = Gson()
                        mensaje = gson.fromJson(result, Mensaje::class.java)
                    }
                }
    }

    fun comprobarFechas(){
        val sdf = SimpleDateFormat("yyyy/MM/dd")
        val currentDate = sdf.format(Date())
        val diaActual = sdf.toString().substring(8,10).toInt()
        val mesActual = sdf.toString().substring(5, 7).toInt()
        val anioActual = sdf.toString().substring(0, 4).toInt()
        val diaCita = cita?.fecha.toString().substring(8, 10).toInt()
        val mesCita = cita?.fecha.toString().substring(5, 7).toInt()
        val anioCita = cita?.fecha.toString().substring(0, 4).toInt()
        if(diaActual > diaCita && mesActual >= mesCita && anioActual >= anioCita){
                MaterialAlertDialogBuilder(this@Principal)
                        .setTitle("Cancelar cita")
                        .setMessage("¿Estás seguro que deseas cancelar la cita?")
                        .setNegativeButton("Cancelar") { dialog, which ->
                            // Respond to negative button press
                        }
                        .setPositiveButton("Aceptar") { dialog, which ->
                            Ion.with(this@Principal)
                                    .load("DELETE", "http://192.168.100.4:8084/FitNutritionWS/ws/citas/eliminarCita")
                                    .setHeader("Content-Type", "application/x-www-form-urlencoded")
                                    .setBodyParameter("idPaciente", cita?.idCita.toString())
                                    .asString()
                                    .setCallback{e, result ->
                                        if(e!=null){
                                            e.printStackTrace()
                                            Toast.makeText(this@Principal, e.message, Toast.LENGTH_LONG).show()
                                        }else{
                                            Log.d("Respuesta WS", result)
                                            val gson = Gson()
                                            mensaje = gson.fromJson(result ,Mensaje::class.java)
                                            if(mensaje.error?.equals(false) == true){
                                                cvCitaCancelada.visibility = View.VISIBLE
                                                cvCitaProxima.visibility = View.GONE
                                                MaterialAlertDialogBuilder(this@Principal)
                                                        .setTitle("Cita cancelada")
                                                        .setMessage("La cita ha sido cancelada con éxito")
                                                        .setPositiveButton("Aceptar") { dialog, which ->

                                                        }
                                                        .show()
                                            }else{
                                                MaterialAlertDialogBuilder(this@Principal)
                                                        .setTitle("Cita no cancelada")
                                                        .setMessage("La cita no ha podido ser cancelada")
                                                        .setPositiveButton("Aceptar") { dialog, which ->

                                                        }
                                                        .show()
                                            }
                                        }
                                    }
                        }
                        .show()
            }else{
            MaterialAlertDialogBuilder(this@Principal)
                    .setTitle("La cita no se puede cancelar")
                    .setMessage("Para cancelar la cita debe ser al menos con un día de anticipación")
                    .setPositiveButton("Aceptar") { dialog, which ->

                    }
                    .show()
            }
    }
}

