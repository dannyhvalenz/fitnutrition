package com.example.fitnutrition.adaptador

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Cita
import kotlinx.android.synthetic.main.fragment_citas.*


class AdaptadorListaCita (idPaciente : String, fecha : String): RecyclerView.Adapter<AdaptadorListaCita.ViewHolder>(){
    var fecha = fecha
    var idPaciente = idPaciente
    var citas = ArrayList<Cita>()
        set(value) {
            field = value
        }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val card = LayoutInflater.from(parent.context).inflate(R.layout.adapter_lista_citas_anteriores, parent, false)
        return ViewHolder(card)
    }

    override fun getItemCount(): Int {
        return citas.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val cit = citas.get(position)
        if(cit.idPaciente.toString() == idPaciente){
            if(cit.fecha.equals(fecha)){
                holder.cvDietaAnterior.visibility = View.GONE
            }
            holder.txtFechaCitaAnterior.text = "Fecha: " + cit.fecha
            System.out.println("Fecha: " + cit.fecha)
            holder.txtHoraCitaAnterior.text = "Hora: " + cit.hora
            holder.txtComentarioCitaAnterior.text = "Comentarios: " + cit.observaciones
        }else{
            holder.cvDietaAnterior.visibility = View.GONE
        }
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var txtFechaCitaAnterior : TextView
        var txtHoraCitaAnterior : TextView
        var txtComentarioCitaAnterior : TextView
        var btnOcultarDetalleCitaAnterior : ImageButton
        var btnMuestraDetalleCitaAnterior : ImageButton
        lateinit var cvDietaAnterior : CardView
        lateinit var lyInfoComentariosCitaAnterior : LinearLayout
        lateinit var lyTxtDetallesCitaAnterior : LinearLayout
        init {
            txtFechaCitaAnterior = itemView.findViewById(R.id.txtFechaCitaAnterior)
            txtHoraCitaAnterior = itemView.findViewById(R.id.txtHoraCitaAnterior)
            txtComentarioCitaAnterior = itemView.findViewById(R.id.txtComentarioCitaAnterior)
            btnMuestraDetalleCitaAnterior = itemView.findViewById(R.id.btnMuestraDetalleCitaAnterior)
            btnOcultarDetalleCitaAnterior = itemView.findViewById(R.id.btnOcultarDetalleCitaAnterior)
            lyInfoComentariosCitaAnterior = itemView.findViewById(R.id.lyInfoComentariosCitaAnterior)
            lyTxtDetallesCitaAnterior = itemView.findViewById(R.id.lyTxtDetallesCitaAnterior)
            cvDietaAnterior = itemView.findViewById(R.id.cvDietaAnterior)
            btnMuestraDetalleCitaAnterior.setOnClickListener(View.OnClickListener{
                lyInfoComentariosCitaAnterior.visibility = View.VISIBLE
                lyTxtDetallesCitaAnterior.visibility = View.VISIBLE
                btnOcultarDetalleCitaAnterior.visibility = View.VISIBLE
                btnMuestraDetalleCitaAnterior.visibility = View.GONE
            })
            btnOcultarDetalleCitaAnterior.setOnClickListener(View.OnClickListener{
                lyInfoComentariosCitaAnterior.visibility = View.GONE
                lyTxtDetallesCitaAnterior.visibility = View.GONE
                btnOcultarDetalleCitaAnterior.visibility = View.GONE
                btnMuestraDetalleCitaAnterior.visibility = View.VISIBLE
            })
        }
    }
}