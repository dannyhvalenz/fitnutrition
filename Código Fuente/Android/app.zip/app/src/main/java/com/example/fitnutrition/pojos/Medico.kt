package com.example.fitnutrition.pojos

import java.util.*

class Medico {
    val nombre: String = ""
    var apellidos:String = ""
    var genero:String = ""
    var domicilio:String = ""
    var num_personal:String = ""
    var num_cedula:String = ""
    var contrasena:String = ""
    var status: String = ""
    val idMedico : Int = 0
    val fotografia: ByteArray
        get() {
            TODO()
        }
    val fecha_nacimiento: String = ""
}