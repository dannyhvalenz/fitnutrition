package com.example.fitnutrition.util

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.fitnutrition.R
import com.example.fitnutrition.pojos.Mensaje
import com.example.fitnutrition.pojos.Paciente
import com.google.gson.Gson
import com.koushikdutta.ion.Ion
import java.io.ByteArrayOutputStream
import java.io.InputStream

class PerfilSubeFoto : AppCompatActivity() {
    private lateinit var imgPruebaImagen : ImageView
    private lateinit var btnAbrirGaleria : Button
    private lateinit var btnSubirImg : Button
    private var byteImages : ByteArray? = null
    private var paciente = Paciente()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil_sube_foto)
        paciente = intent.getSerializableExtra("paciente") as Paciente
        imgPruebaImagen = findViewById(R.id.imgPruebaImagen)
        btnAbrirGaleria = findViewById(R.id.btnAbrirGaleria)
        btnSubirImg = findViewById(R.id.btnSubirImg)
        btnAbrirGaleria.setOnClickListener(View.OnClickListener() {
            abrirGaleria()
        })
        btnSubirImg.setOnClickListener(View.OnClickListener {
            subirImagen()
        })
    }

    fun abrirGaleria(){
        intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.setType("image/")
        startActivityForResult(Intent.createChooser(intent, "Seleccione la aplicación"), 10)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode== RESULT_OK){
            val path : Uri = data?.getData()!!
            byteImages = readBytes(path)
            System.out.println(byteImages)
            imgPruebaImagen.setImageURI(path)
            btnSubirImg.visibility = View.VISIBLE
        }
    }

    fun readBytes(uri: Uri): ByteArray? {
        val stream : InputStream? =  getContentResolver().openInputStream(uri)
        val byteArrayStream = ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        var i: Int = Int.MAX_VALUE
        while ((stream?.read(buffer, 0, buffer.size)!!.also { i = it }) > 0){
            byteArrayStream.write(buffer, 0, i)
        }
        /*while (stream?.read(buffer, 0, buffer.size).also { i = it } > 0) {
            byteArrayStream.write(buffer, 0, i)
        }*/
        return byteArrayStream.toByteArray()
    }

    fun subirImagen(){
        Ion.getDefault(this@PerfilSubeFoto).conscryptMiddleware.enable(false)
        Ion.with(this@PerfilSubeFoto)
                .load("POST", "http://192.168.100.4:8084/FitNutritionWS/ws/pacientes/subirFotografia/"+paciente.idPaciente)
                .setHeader("Content-Type", "image/jpg")
                .setBodyParameter("fotografia", byteImages.toString())
                .asString()
                .setCallback { e, result ->
                    if(e != null){
                        e.printStackTrace()
                        Toast.makeText(this@PerfilSubeFoto, "Error: "+e.message, Toast.LENGTH_LONG).show()
                    }else{
                        System.out.println(result)
                        val gson = Gson()
                        val msj : Mensaje = gson.fromJson(result, Mensaje::class.java)
                        if(msj.error!!){
                            Toast.makeText(this@PerfilSubeFoto, msj.mensaje, Toast.LENGTH_LONG).show()
                        }else{
                            Toast.makeText(this@PerfilSubeFoto, msj.mensaje, Toast.LENGTH_LONG).show()
                        }
                    }
                }
    }
}