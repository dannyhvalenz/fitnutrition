package util;

public class Constantes {
    public static final String URL = "http://localhost:8084/FitNutritionWS/ws/";
    public static final int TIME_OUT = 10000;
}
