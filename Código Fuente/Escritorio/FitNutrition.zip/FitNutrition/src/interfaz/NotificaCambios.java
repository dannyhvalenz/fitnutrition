package interfaz;

public interface NotificaCambios {
    
    public void refrescarTabla(boolean isReload);
}
